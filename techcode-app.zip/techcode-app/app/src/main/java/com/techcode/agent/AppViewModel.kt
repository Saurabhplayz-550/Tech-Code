package com.techcode.agent

import android.app.Application
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

sealed interface Screen {
    data object Chat : Screen
    data object Settings : Screen
    data class Diff(val csId: String) : Screen
}

class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val appCtx: Application = app

    private val store = Store(app)
    private val lock = Any()
    private var job: Job? = null

    var settings by mutableStateOf(store.loadSettings())
        private set
    var projects by mutableStateOf(store.loadProjects())
        private set
    var chats by mutableStateOf(store.loadChats())
        private set
    var currentProjectId by mutableStateOf<String?>(null)
        private set
    var currentChatId by mutableStateOf<String?>(null)
        private set
    var items by mutableStateOf<List<ChatItem>>(emptyList())
        private set
    var running by mutableStateOf(false)
        private set
    var stages by mutableStateOf<List<Stage>?>(null)
        private set
    var screen by mutableStateOf<Screen>(Screen.Chat)

    val changeSets = mutableStateMapOf<String, ChangeSet>()

    val currentProject: Project? get() = projects.find { it.id == currentProjectId }
    val projectChats: List<Chat>
        get() = chats.filter { it.projectId == currentProjectId }.sortedByDescending { it.updatedAt }

    init {
        val last = store.lastProjectId()
        val start = projects.find { it.id == last } ?: projects.firstOrNull()
        if (start != null) selectProject(start.id)
    }

    private fun toast(msg: String) {
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(appCtx, msg, Toast.LENGTH_LONG).show()
        }
    }

    // ---------------------------------------------------------------- settings

    fun updateSettings(f: (AppSettings) -> AppSettings) {
        settings = f(settings)
        store.saveSettings(settings)
    }

    // ---------------------------------------------------------------- projects & chats

    fun createProject(name: String, folderUri: String) {
        val p = Project(newId(), name.trim().ifEmpty { "My project" }, folderUri, System.currentTimeMillis())
        projects = projects + p
        store.saveProjects(projects)
        selectProject(p.id)
    }

    fun selectProject(id: String) {
        if (running) return
        currentProjectId = id
        store.saveLastProjectId(id)
        screen = Screen.Chat
        val list = chats.filter { it.projectId == id }.sortedByDescending { it.updatedAt }
        if (list.isEmpty()) newChat() else openChat(list.first().id)
    }

    fun openChat(id: String) {
        if (running) return
        currentChatId = id
        items = store.loadItems(id)
        screen = Screen.Chat
        val refs = items.filter { it.kind == Kind.CHANGES }.map { it.ref }
        if (refs.isNotEmpty()) {
            viewModelScope.launch(Dispatchers.IO) {
                refs.forEach { r ->
                    if (changeSets[r] == null) store.loadChangeSet(r)?.let { changeSets[r] = it }
                }
            }
        }
    }

    fun newChat() {
        if (running) return
        val pid = currentProjectId ?: return
        val cur = chats.find { it.id == currentChatId }
        if (cur != null && cur.projectId == pid && items.isEmpty()) {
            screen = Screen.Chat
            return
        }
        val c = Chat(newId(), pid, "New chat", System.currentTimeMillis())
        chats = chats + c
        store.saveChats(chats)
        currentChatId = c.id
        items = emptyList()
        screen = Screen.Chat
    }

    fun deleteChat(id: String) {
        if (running) return
        chats.find { it.id == id }?.let { c ->
            store.deleteChatFile(id)
            chats = chats.filter { it.id != id }
            store.saveChats(chats)
            if (currentChatId == id) {
                val next = chats.filter { it.projectId == c.projectId }.maxByOrNull { it.updatedAt }
                if (next != null) openChat(next.id) else {
                    currentChatId = null
                    items = emptyList()
                    newChat()
                }
            }
        }
    }

    fun deleteProject(id: String) {
        if (running) return
        chats.filter { it.projectId == id }.forEach { store.deleteChatFile(it.id) }
        chats = chats.filter { it.projectId != id }
        store.saveChats(chats)
        projects = projects.filter { it.id != id }
        store.saveProjects(projects)
        if (currentProjectId == id) {
            currentProjectId = null
            currentChatId = null
            items = emptyList()
            store.saveLastProjectId(null)
            projects.firstOrNull()?.let { selectProject(it.id) }
        }
    }

    // ---------------------------------------------------------------- running the agent

    private fun addItem(item: ChatItem) {
        synchronized(lock) { items = items + item }
    }

    private fun persist(chatId: String) {
        store.saveItems(chatId, items)
        chats = chats.map { if (it.id == chatId) it.copy(updatedAt = System.currentTimeMillis()) else it }
        store.saveChats(chats)
    }

    private fun buildContext(): String {
        val recent = items.filter { it.kind == Kind.USER || it.kind == Kind.AI }.takeLast(10)
        return recent.joinToString("\n") {
            (if (it.kind == Kind.USER) "User: " else "Assistant: ") + it.text.take(600)
        }
    }

    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty() || running) return
        val project = currentProject ?: return
        val chatId = currentChatId ?: return
        if (!settings.hasAnyKey()) {
            addItem(ChatItem(kind = Kind.ERROR, text = "Pehle Settings mein Gemini API key daalo."))
            return
        }
        val context = buildContext()
        addItem(ChatItem(kind = Kind.USER, text = t))
        chats.find { it.id == chatId }?.let { c ->
            if (c.title == "New chat") {
                chats = chats.map { if (it.id == chatId) it.copy(title = t.take(40)) else it }
            }
        }
        val s = settings
        running = true
        job = viewModelScope.launch(Dispatchers.IO) {
            try {
                val files = ProjectFiles(appCtx, Uri.parse(project.folderUri))
                if (!files.canAccess()) {
                    throw IllegalStateException("Folder access nahi mil raha. Project delete karke folder dobara chuno.")
                }
                val cb = RunCallbacks(
                    onTool = { o, role ->
                        addItem(
                            ChatItem(
                                kind = Kind.TOOL,
                                text = if (role.isEmpty()) o.label else "$role · ${o.label}",
                                sub = o.sub
                            )
                        )
                    },
                    onStages = { stages = it }
                )
                val result = if (s.mode == Mode.TEAM) {
                    Runner.runTeam(s, files, t, context, cb)
                } else {
                    Runner.runSingle(s, files, t, context, cb)
                }
                stages = null
                if (result.summary.isNotBlank()) addItem(ChatItem(kind = Kind.AI, text = result.summary))

                val changes = result.changes.mapNotNull { (path, new) ->
                    val old = files.readText(path)
                    if (old == new) null else FileChange(path, old, new)
                }
                if (changes.isNotEmpty()) {
                    val cs = ChangeSet(newId(), project.id, changes, ChangeStatus.PENDING, result.summary)
                    store.saveChangeSet(cs)
                    changeSets[cs.id] = cs
                    addItem(ChatItem(kind = Kind.CHANGES, text = "${changes.size} files", ref = cs.id))
                } else if (result.summary.isBlank()) {
                    addItem(ChatItem(kind = Kind.AI, text = "Koi change nahi hua."))
                }
            } catch (e: CancellationException) {
                addItem(ChatItem(kind = Kind.ERROR, text = "Roka gaya."))
            } catch (e: Exception) {
                addItem(ChatItem(kind = Kind.ERROR, text = e.message ?: e.toString()))
            } finally {
                stages = null
                running = false
                persist(chatId)
            }
        }
    }

    fun stop() {
        job?.cancel()
    }

    // ---------------------------------------------------------------- change sets

    fun openDiff(csId: String) {
        screen = Screen.Diff(csId)
        if (changeSets[csId] == null) {
            viewModelScope.launch(Dispatchers.IO) {
                store.loadChangeSet(csId)?.let { changeSets[csId] = it }
            }
        }
    }

    fun closeDiff() {
        screen = Screen.Chat
    }

    private fun update(cs: ChangeSet) {
        changeSets[cs.id] = cs
        store.saveChangeSet(cs)
    }

    fun approve(csId: String) {
        val cs = changeSets[csId] ?: return
        if (cs.status != ChangeStatus.PENDING) return
        val project = projects.find { it.id == cs.projectId } ?: return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val files = ProjectFiles(appCtx, Uri.parse(project.folderUri))
                val failed = cs.files.filter { !files.writeText(it.path, it.newContent) }.map { it.path }
                update(cs.copy(status = ChangeStatus.APPLIED))
                toast(
                    if (failed.isEmpty()) "Changes apply ho gaye"
                    else "Ye files likh nahi payi: ${failed.joinToString(", ")}"
                )
            } catch (e: Exception) {
                toast("Apply fail: ${e.message}")
            }
            screen = Screen.Chat
        }
    }

    fun reject(csId: String) {
        val cs = changeSets[csId] ?: return
        if (cs.status != ChangeStatus.PENDING) return
        update(cs.copy(status = ChangeStatus.REJECTED))
        screen = Screen.Chat
    }

    fun undo(csId: String) {
        val cs = changeSets[csId] ?: return
        if (cs.status != ChangeStatus.APPLIED) return
        val project = projects.find { it.id == cs.projectId } ?: return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val files = ProjectFiles(appCtx, Uri.parse(project.folderUri))
                cs.files.forEach { f ->
                    if (f.oldContent == null) files.delete(f.path) else files.writeText(f.path, f.oldContent)
                }
                update(cs.copy(status = ChangeStatus.UNDONE))
                toast("Undo ho gaya")
            } catch (e: Exception) {
                toast("Undo fail: ${e.message}")
            }
            screen = Screen.Chat
        }
    }
}
