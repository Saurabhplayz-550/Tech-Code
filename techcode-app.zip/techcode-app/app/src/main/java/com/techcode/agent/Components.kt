@file:OptIn(ExperimentalMaterial3Api::class)

package com.techcode.agent

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun Logo(size: Int, modifier: Modifier = Modifier) {
    Image(
        painter = painterResource(R.drawable.logo),
        contentDescription = "TechCode",
        modifier = modifier.size(size.dp).clip(RoundedCornerShape((size / 4).dp))
    )
}

@Composable
fun UserBubble(text: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
        Text(
            text = text,
            color = Color.White,
            fontSize = 15.sp,
            lineHeight = 22.sp,
            modifier = Modifier
                .widthIn(max = 300.dp)
                .clip(RoundedCornerShape(18.dp, 18.dp, 4.dp, 18.dp))
                .background(TC.Blue)
                .padding(horizontal = 14.dp, vertical = 11.dp)
        )
    }
}

private sealed interface Seg {
    data class T(val s: String) : Seg
    data class C(val lang: String, val code: String) : Seg
}

private fun splitFences(text: String): List<Seg> {
    val out = ArrayList<Seg>()
    text.split("```").forEachIndexed { i, p ->
        if (i % 2 == 0) {
            if (p.isNotBlank()) out.add(Seg.T(p.trim()))
        } else {
            val nl = p.indexOf('\n')
            val lang = if (nl >= 0) p.substring(0, nl).trim() else ""
            val code = if (nl >= 0) p.substring(nl + 1) else p
            out.add(Seg.C(lang, code.trimEnd()))
        }
    }
    return out
}

@Composable
fun AiMessage(text: String) {
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.Top) {
        Logo(30, Modifier.padding(top = 2.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            splitFences(text).forEach { seg ->
                when (seg) {
                    is Seg.T -> SelectionContainer {
                        Text(seg.s, fontSize = 15.sp, lineHeight = 22.sp, color = TC.Text)
                    }
                    is Seg.C -> CodeBlock(seg.lang, seg.code)
                }
            }
        }
    }
}

@Composable
fun CodeBlock(lang: String, code: String) {
    val clipboard = LocalClipboardManager.current
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(TC.CodeBg)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 14.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                lang.ifEmpty { "code" },
                color = Color(0xFFC7D6FF),
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = { clipboard.setText(AnnotatedString(code)) }) {
                Icon(Icons.Default.ContentCopy, contentDescription = null, tint = Color(0xFFC7D6FF), modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Copy", color = Color(0xFFC7D6FF), fontSize = 12.sp)
            }
        }
        SelectionContainer {
            Text(
                code,
                color = TC.CodeFg,
                fontSize = 12.5.sp,
                lineHeight = 20.sp,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(start = 14.dp, end = 14.dp, bottom = 14.dp)
            )
        }
    }
}

private fun toolIcon(label: String): ImageVector = when {
    label.contains("failed") -> Icons.Default.Warning
    label.contains("Issues") -> Icons.Default.Warning
    label.contains("Verified") -> Icons.Default.Check
    label.contains("Search") -> Icons.Default.Search
    label.contains("Listed") -> Icons.Default.Folder
    label.contains("Edited") || label.contains("Rewrote") || label.contains("Created") -> Icons.Default.Edit
    else -> Icons.Default.Description
}

@Composable
fun ToolCard(item: ChatItem) {
    val bad = item.text.contains("failed") || item.text.contains("Issues")
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(if (bad) TC.RedSoft else TC.Card)
            .border(1.dp, if (bad) Color(0xFFF3C2C2) else TC.Border, RoundedCornerShape(12.dp))
            .padding(horizontal = 12.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Icon(toolIcon(item.text), null, tint = if (bad) TC.Red else TC.Blue, modifier = Modifier.size(18.dp))
        Column(Modifier.weight(1f)) {
            Text(item.text, fontSize = 12.sp, color = TC.Muted)
            if (item.sub.isNotEmpty()) {
                Text(
                    item.sub,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    color = TC.Navy,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun ErrorCard(text: String) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(TC.RedSoft)
            .border(1.dp, Color(0xFFF3C2C2), RoundedCornerShape(12.dp))
            .padding(12.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Icon(Icons.Default.Warning, null, tint = TC.Red, modifier = Modifier.size(18.dp))
        SelectionContainer {
            Text(text, fontSize = 14.sp, lineHeight = 20.sp, color = Color(0xFF7F1D1D))
        }
    }
}

@Composable
fun ChangesCard(cs: ChangeSet?, fallbackText: String, onOpen: () -> Unit, onUndo: () -> Unit) {
    val files = cs?.files?.size ?: 0
    val status = cs?.status
    val (label, color) = when (status) {
        ChangeStatus.PENDING, null -> "Approval chahiye" to TC.Blue
        ChangeStatus.APPLIED -> "Apply ho gaya" to TC.Green
        ChangeStatus.REJECTED -> "Reject kiya" to TC.Muted
        ChangeStatus.UNDONE -> "Undo ho gaya" to TC.Muted
    }
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color.White)
            .border(1.5.dp, if (status == ChangeStatus.PENDING || status == null) TC.Blue else TC.Border, RoundedCornerShape(12.dp))
            .clickable(onClick = onOpen)
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Icon(Icons.Default.Edit, null, tint = TC.Blue, modifier = Modifier.size(18.dp))
            Column(Modifier.weight(1f)) {
                Text(label, fontSize = 12.sp, color = color, fontWeight = FontWeight.SemiBold)
                Text(
                    if (cs != null) "$files file${if (files == 1) "" else "s"} badle" else fallbackText,
                    fontSize = 14.sp, color = TC.Navy, fontWeight = FontWeight.SemiBold
                )
                if (cs != null) {
                    Text(
                        cs.files.joinToString(", ") { it.path.substringAfterLast('/') },
                        fontSize = 12.sp, fontFamily = FontFamily.Monospace, color = TC.Muted,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
            }
            Icon(Icons.Default.ChevronRight, null, tint = TC.Navy)
        }
        if (status == ChangeStatus.APPLIED) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = onUndo) {
                    Icon(Icons.Default.Refresh, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Undo")
                }
            }
        }
    }
}

@Composable
fun RunningCard(stages: List<Stage>?) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(TC.Card)
            .border(1.dp, TC.Border, RoundedCornerShape(14.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        if (stages == null) {
            Text("Agent kaam kar raha hai...", fontSize = 13.sp, color = TC.Navy, fontWeight = FontWeight.SemiBold)
            LinearProgressIndicator(Modifier.fillMaxWidth(), color = TC.Blue, trackColor = TC.Border)
        } else {
            Text("Team kaam kar rahi hai", fontSize = 13.sp, color = TC.Navy, fontWeight = FontWeight.SemiBold)
            stages.forEach { st ->
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StageDot(st.state)
                    Text(st.name, fontSize = 14.sp, color = TC.Text, fontWeight = FontWeight.Medium, modifier = Modifier.width(56.dp))
                    Text(
                        when (st.state) {
                            StageState.WAIT -> "wait" + if (st.note.isNotEmpty()) " · ${st.note}" else ""
                            StageState.RUN -> "chal raha hai" + if (st.note.isNotEmpty()) " · ${st.note}" else ""
                            StageState.DONE -> "done" + if (st.note.isNotEmpty()) " · ${st.note}" else ""
                            StageState.FAIL -> "fail" + if (st.note.isNotEmpty()) " · ${st.note}" else ""
                        },
                        fontSize = 12.sp, color = TC.Muted, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
private fun StageDot(state: StageState) {
    when (state) {
        StageState.WAIT -> Box(Modifier.size(18.dp).clip(CircleShape).border(2.dp, TC.BorderStrong, CircleShape))
        StageState.RUN -> Box(
            Modifier.size(18.dp).clip(CircleShape).background(TC.Cyan).border(2.dp, TC.Blue, CircleShape)
        )
        StageState.DONE -> Box(
            Modifier.size(18.dp).clip(CircleShape).background(TC.Green),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(12.dp)) }
        StageState.FAIL -> Box(
            Modifier.size(18.dp).clip(CircleShape).background(TC.Red),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Default.Warning, null, tint = Color.White, modifier = Modifier.size(11.dp)) }
    }
}

@Composable
fun EmptyChat(projectName: String, onPick: (String) -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(top = 40.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Logo(72)
        Spacer(Modifier.height(6.dp))
        Text("Kya banana hai?", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = TC.Navy)
        Text(
            "Agent $projectName folder ke andar kaam karega.",
            fontSize = 14.sp, color = TC.Muted
        )
        Spacer(Modifier.height(8.dp))
        listOf(
            "Is project ko samjhao aur batao kya kya files hain",
            "Ek README.md banao is project ke liye",
            "Code mein bugs dhundho aur fix karo"
        ).forEach { s ->
            Text(
                s,
                fontSize = 14.sp,
                color = TC.Navy,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(TC.Card)
                    .border(1.dp, TC.Border, RoundedCornerShape(14.dp))
                    .clickable { onPick(s) }
                    .padding(horizontal = 14.dp, vertical = 12.dp)
            )
        }
    }
}
