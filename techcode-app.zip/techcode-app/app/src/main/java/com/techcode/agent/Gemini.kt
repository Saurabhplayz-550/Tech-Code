package com.techcode.agent

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class GeminiException(message: String, val code: Int = 0) : Exception(message)

/** Minimal Gemini REST client with function calling (no extra libraries). */
class GeminiClient(private val apiKey: String, private val model: String) {

    /** Returns the model's `content` object ({role, parts}). */
    suspend fun generate(system: String, contents: JSONArray, tools: JSONArray?): JSONObject {
        if (apiKey.isBlank()) throw GeminiException("API key nahi hai. Settings mein key daalo.")

        val body = JSONObject()
        body.put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
        body.put("contents", contents)
        if (tools != null && tools.length() > 0) {
            body.put("tools", tools)
            body.put(
                "toolConfig",
                JSONObject().put("functionCallingConfig", JSONObject().put("mode", "AUTO"))
            )
        }
        body.put("generationConfig", JSONObject().put("temperature", 0.4))

        val payload = body.toString().toByteArray(Charsets.UTF_8)
        var attempt = 0
        while (true) {
            attempt++
            val result = withContext(Dispatchers.IO) { post(payload) }
            val code = result.first
            val text = result.second
            if (code in 200..299) return parse(text)

            val retryable = code == -1 || code == 429 || code == 500 || code == 502 || code == 503 || code == 504
            if (retryable && attempt < 4) {
                delay(3000L * attempt)
                continue
            }
            throw GeminiException(errorMessage(code, text), code)
        }
    }

    private fun post(payload: ByteArray): Pair<Int, String> {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
        val conn = url.openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 20_000
            conn.readTimeout = 180_000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("x-goog-api-key", apiKey)
            conn.outputStream.use { it.write(payload) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            return code to text
        } catch (e: java.io.IOException) {
            return -1 to (e.message ?: "network error")
        } finally {
            conn.disconnect()
        }
    }

    private fun errorMessage(code: Int, text: String): String {
        if (code == -1) return "Network error: $text"
        val msg = runCatching { JSONObject(text).getJSONObject("error").getString("message") }.getOrNull()
        return when (code) {
            400 -> "Gemini 400: ${msg ?: "bad request"} (key ya model name check karo)"
            403 -> "Gemini 403: ${msg ?: "key ko permission nahi"}"
            404 -> "Gemini 404: model '$model' nahi mila. Model name check karo."
            429 -> "Gemini 429: rate limit / quota khatam. Thoda ruk ke try karo ya doosri key use karo."
            else -> "Gemini $code: ${msg ?: text.take(200)}"
        }
    }

    private fun parse(text: String): JSONObject {
        val root = JSONObject(text)
        val cands = root.optJSONArray("candidates")
        if (cands == null || cands.length() == 0) {
            val reason = root.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
            throw GeminiException("Model ne jawab nahi diya${if (reason.isNotEmpty()) " (blocked: $reason)" else ""}")
        }
        val content = cands.getJSONObject(0).optJSONObject("content") ?: JSONObject()
        if (!content.has("role")) content.put("role", "model")
        if (!content.has("parts")) content.put("parts", JSONArray())
        return content
    }
}
