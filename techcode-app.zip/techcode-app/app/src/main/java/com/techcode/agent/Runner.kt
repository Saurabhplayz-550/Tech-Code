package com.techcode.agent

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import org.json.JSONArray

class RunCallbacks(
    /** (outcome, role label; empty in single mode) */
    val onTool: (ToolOutcome, String) -> Unit,
    val onStages: (List<Stage>?) -> Unit
)

data class RunResult(val changes: Map<String, String>, val summary: String, val warnings: List<String>)

private suspend fun GeminiClient.ask(system: String, prompt: String): String {
    val content = generate(system, JSONArray().put(userContent(prompt)), null)
    val parts = content.optJSONArray("parts") ?: return ""
    val sb = StringBuilder()
    for (i in 0 until parts.length()) {
        val p = parts.getJSONObject(i)
        if (p.has("text") && !p.optBoolean("thought", false)) sb.append(p.getString("text"))
    }
    return sb.toString().trim()
}

private suspend fun <T> attempt(block: suspend () -> T): Result<T> =
    try {
        Result.success(block())
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        Result.failure(e)
    }

object Runner {

    private fun instructions(files: ProjectFiles): String? =
        files.readText("TECHCODE.md") ?: files.readText("CLAUDE.md")

    // ------------------------------------------------------------------ single

    suspend fun runSingle(
        settings: AppSettings,
        files: ProjectFiles,
        request: String,
        context: String,
        cb: RunCallbacks
    ): RunResult {
        val ws = Workspace(files, files.listAll())
        val client = GeminiClient(settings.keyFor(0), settings.singleModel.trim().ifBlank { DEFAULT_MODEL })
        val ctx = ToolContext("Agent", ws)
        val runner = AgentRunner(
            client, Prompts.base(instructions(files)), Tools.readWrite(), ctx,
            { cb.onTool(it, "") }
        )
        val summary = runner.run(Prompts.task(request, context))
        return RunResult(ws.proposals(), summary, emptyList())
    }

    // ------------------------------------------------------------------ team

    suspend fun runTeam(
        settings: AppSettings,
        files: ProjectFiles,
        request: String,
        context: String,
        cb: RunCallbacks
    ): RunResult = coroutineScope {
        val base = files.listAll()
        val instr = instructions(files)
        val warnings = ArrayList<String>()
        val task = Prompts.task(request, context)

        val stages = ArrayList<Stage>(ROLE_NAMES.map { Stage(it, StageState.WAIT) })
        fun setStage(i: Int, state: StageState, note: String = "") {
            val snapshot = synchronized(stages) {
                stages[i] = Stage(ROLE_NAMES[i], state, note)
                ArrayList(stages)
            }
            cb.onStages(snapshot)
        }
        cb.onStages(ArrayList(stages))

        fun client(slot: Int) = GeminiClient(settings.keyFor(slot), settings.models[slot].trim().ifBlank { DEFAULT_MODEL })

        suspend fun runRole(
            slot: Int, role: String, ws: Workspace, system: String, prompt: String, tools: JSONArray,
            roleWorkspaces: Map<String, Workspace> = emptyMap()
        ): String {
            val ctx = ToolContext(role, ws, roleWorkspaces)
            return AgentRunner(client(slot), system, tools, ctx, { cb.onTool(it, role) }).run(prompt)
        }

        // 1) shared plan (Merge model acts as tech lead)
        setStage(2, StageState.RUN, "plan")
        val plan = client(2).ask(
            Prompts.PLANNER,
            task + "\n\nProject files:\n" + base.joinToString("\n").ifEmpty { "(empty project)" }
        )
        setStage(2, StageState.WAIT)

        // 2) UI and Logic work in parallel, each on its own staging area
        val uiWs = Workspace(files, base)
        val logicWs = Workspace(files, base)
        setStage(0, StageState.RUN)
        setStage(1, StageState.RUN)
        val uiJob = async {
            attempt {
                runRole(0, "UI", uiWs, Prompts.ui(instr, plan), task, Tools.readWrite())
            }
        }
        val logicJob = async {
            attempt {
                runRole(1, "Logic", logicWs, Prompts.logic(instr, plan), task, Tools.readWrite())
            }
        }
        val uiRes = uiJob.await()
        val logicRes = logicJob.await()
        if (uiRes.isFailure && logicRes.isFailure) {
            setStage(0, StageState.FAIL)
            setStage(1, StageState.FAIL)
            throw uiRes.exceptionOrNull() ?: Exception("UI aur Logic dono fail hue")
        }
        if (uiRes.isFailure) {
            setStage(0, StageState.FAIL)
            warnings.add("UI model fail hua: ${uiRes.exceptionOrNull()?.message}")
        } else setStage(0, StageState.DONE)
        if (logicRes.isFailure) {
            setStage(1, StageState.FAIL)
            warnings.add("Logic model fail hua: ${logicRes.exceptionOrNull()?.message}")
        } else setStage(1, StageState.DONE)

        val uiText = uiRes.getOrNull().orEmpty()
        val logicText = logicRes.getOrNull().orEmpty()
        val uiP = uiWs.proposals()
        val logicP = logicWs.proposals()

        // 3) merge
        val merged = Workspace(files, base)
        val conflicts = uiP.keys.intersect(logicP.keys).filter { uiP[it] != logicP[it] }.toSet()
        for ((p, c) in uiP) if (p !in conflicts) merged.write(p, c)
        for ((p, c) in logicP) if (p !in conflicts) merged.write(p, c)

        var mergeText = ""
        if (uiP.isNotEmpty() && logicP.isNotEmpty()) {
            setStage(2, StageState.RUN, if (conflicts.isEmpty()) "check" else "${conflicts.size} conflicts")
            val mergeTask = buildString {
                append(task)
                append("\n\nUI specialist's summary:\n").append(uiText.ifBlank { "(none)" })
                append("\n\nLogic specialist's summary:\n").append(logicText.ifBlank { "(none)" })
                append("\n\nFiles changed by UI: ").append(uiP.keys.joinToString(", ").ifEmpty { "none" })
                append("\nFiles changed by Logic: ").append(logicP.keys.joinToString(", ").ifEmpty { "none" })
                append("\nConflicting files (both changed, you must combine): ")
                append(conflicts.joinToString(", ").ifEmpty { "none" })
            }
            val r = attempt {
                runRole(
                    2, "Merge", merged, Prompts.merge(instr, plan), mergeTask, Tools.merger(),
                    mapOf("ui" to uiWs, "logic" to logicWs)
                )
            }
            if (r.isFailure) {
                setStage(2, StageState.FAIL)
                warnings.add("Merge model fail hua: ${r.exceptionOrNull()?.message}")
            } else {
                mergeText = r.getOrNull().orEmpty()
                setStage(2, StageState.DONE)
            }
        } else {
            setStage(2, StageState.DONE, "merge ki zarurat nahi")
        }
        // any conflict the merger did not resolve falls back to the Logic version
        val mergedNow = merged.proposals()
        for (p in conflicts) {
            if (p !in mergedNow) {
                merged.write(p, logicP.getValue(p))
                warnings.add("$p ka conflict resolve nahi hua, Logic wala version rakha")
            }
        }

        // 4) verify, send problems back to their owner, verify again
        var fixRounds = 0
        var finalVerdict: Verdict? = null
        var verified = false
        while (true) {
            val changed = merged.proposals().keys
            if (changed.isEmpty()) {
                setStage(3, StageState.DONE, "kuch change nahi hua")
                break
            }
            setStage(3, StageState.RUN, if (fixRounds == 0) "review" else "re-check $fixRounds/${settings.maxRetries}")
            val vctx = ToolContext("Verify", merged)
            val verifyTask = task + "\n\nChanged files to review: " + changed.joinToString(", ")
            val vr = attempt {
                AgentRunner(
                    client(3), Prompts.VERIFIER, Tools.verifier(), vctx, { cb.onTool(it, "Verify") }
                ).run(verifyTask)
            }
            if (vr.isFailure) {
                setStage(3, StageState.FAIL)
                warnings.add("Verify model fail hua: ${vr.exceptionOrNull()?.message}")
                break
            }
            val v = vctx.verdict
            if (v == null) {
                setStage(3, StageState.DONE, "verdict nahi mila")
                warnings.add("Verifier ne final verdict nahi diya")
                break
            }
            finalVerdict = v
            if (v.ok) {
                verified = true
                setStage(3, StageState.DONE, if (fixRounds == 0) "ok" else "ok after $fixRounds fix")
                break
            }
            if (fixRounds >= settings.maxRetries) {
                setStage(3, StageState.FAIL, "${v.issues.size} issues bache")
                break
            }
            fixRounds++
            setStage(3, StageState.RUN, "fix round $fixRounds/${settings.maxRetries}")

            val groups = v.issues.groupBy {
                when (it.owner) {
                    "ui" -> 0
                    "logic" -> 1
                    else -> 2
                }
            }
            for (slot in listOf(0, 1, 2)) {
                val list = groups[slot] ?: continue
                val role = ROLE_NAMES[slot]
                val system = when (slot) {
                    0 -> Prompts.ui(instr, plan)
                    1 -> Prompts.logic(instr, plan)
                    else -> Prompts.merge(instr, plan)
                }
                val fixTask = buildString {
                    append(task)
                    append("\n\nThe verifier reviewed the combined changes and found these problems for you to fix:\n")
                    list.forEach { append("- ${it.file}: ${it.problem}\n") }
                    append("\nFix only these problems with minimal edits (read the file first), then reply with a short summary.")
                }
                val fr = attempt { runRole(slot, role, merged, system, fixTask, Tools.readWrite()) }
                if (fr.isFailure) warnings.add("$role fix fail hua: ${fr.exceptionOrNull()?.message}")
            }
        }

        val fv = finalVerdict
        val summary = buildString {
            val body = mergeText.ifBlank { listOf(uiText, logicText).filter { it.isNotBlank() }.joinToString("\n\n") }
            append(body.ifBlank { "Kaam ho gaya." })
            append("\n\n")
            when {
                verified -> append("Verifier: sab theek laga" + if (fixRounds > 0) " ($fixRounds baar fix karke)." else ".")
                fv != null -> {
                    append("Verifier ko ye problems mili jo fix nahi ho payi, diff dhyaan se dekho:\n")
                    fv.issues.forEach { append("- ${it.file}: ${it.problem}\n") }
                }
            }
            if (warnings.isNotEmpty()) {
                append("\n")
                warnings.forEach { append("Note: $it\n") }
            }
        }.trim()

        RunResult(merged.proposals(), summary, warnings)
    }
}
