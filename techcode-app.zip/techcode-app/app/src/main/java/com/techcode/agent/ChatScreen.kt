@file:OptIn(ExperimentalMaterial3Api::class)

package com.techcode.agent

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.vector.ImageVector
import kotlinx.coroutines.launch

@Composable
fun ChatScreen(vm: AppViewModel) {
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var showModelSheet by remember { mutableStateOf(false) }
    var showFiles by remember { mutableStateOf(false) }
    var showNewProject by remember { mutableStateOf(false) }

    BackHandler(enabled = drawerState.isOpen) { scope.launch { drawerState.close() } }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            DrawerContent(
                vm = vm,
                onClose = { scope.launch { drawerState.close() } },
                onNewProject = { showNewProject = true }
            )
        }
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .background(Color.White)
                .systemBarsPadding()
                .imePadding()
        ) {
            // ---- header
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { scope.launch { drawerState.open() } }) {
                    Icon(Icons.Default.Menu, contentDescription = "Menu kholo", tint = TC.Navy)
                }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    val project = vm.currentProject
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(Icons.Default.Folder, null, tint = TC.Blue, modifier = Modifier.size(16.dp))
                        Text(
                            project?.name ?: "TechCode",
                            fontWeight = FontWeight.Bold, fontSize = 16.sp, color = TC.Navy,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                    if (project != null) {
                        Text(
                            vm.chats.find { it.id == vm.currentChatId }?.title ?: "",
                            fontSize = 12.sp, color = TC.Muted, maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                IconButton(onClick = { showFiles = true }, enabled = vm.currentProject != null) {
                    Icon(Icons.Default.Folder, contentDescription = "Project files", tint = TC.Navy)
                }
            }
            HorizontalDivider(color = TC.Border)

            if (vm.currentProject == null) {
                NoProject(onCreate = { showNewProject = true })
            } else {
                val listState = rememberLazyListState()
                val extra = if (vm.running) 1 else 0
                val total = vm.items.size + extra
                LaunchedEffect(vm.items.size, vm.running, vm.stages) {
                    if (total > 0) listState.animateScrollToItem(total - 1)
                }
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (vm.items.isEmpty() && !vm.running) {
                        item {
                            EmptyChat(vm.currentProject?.name ?: "project", onPick = { vm.send(it) })
                        }
                    }
                    items(vm.items, key = { it.id }) { item ->
                        when (item.kind) {
                            Kind.USER -> UserBubble(item.text)
                            Kind.AI -> AiMessage(item.text)
                            Kind.TOOL -> ToolCard(item)
                            Kind.ERROR -> ErrorCard(item.text)
                            Kind.CHANGES -> ChangesCard(
                                cs = vm.changeSets[item.ref],
                                fallbackText = item.text,
                                onOpen = { vm.openDiff(item.ref) },
                                onUndo = { vm.undo(item.ref) }
                            )
                        }
                    }
                    if (vm.running) {
                        item(key = "running") { RunningCard(vm.stages) }
                    }
                }

                // ---- input
                InputArea(
                    vm = vm,
                    onModel = { showModelSheet = true },
                    onKeys = { vm.screen = Screen.Settings }
                )
            }
        }
    }

    if (showModelSheet) {
        ModelSheet(
            vm = vm,
            onDismiss = { showModelSheet = false },
            onOpenSettings = {
                showModelSheet = false
                vm.screen = Screen.Settings
            }
        )
    }
    if (showFiles) FilesSheet(vm) { showFiles = false }
    if (showNewProject) {
        NewProjectDialog(
            onDismiss = { showNewProject = false },
            onCreate = { name, uri ->
                showNewProject = false
                vm.createProject(name, uri)
                scope.launch { drawerState.close() }
            }
        )
    }
}

@Composable
private fun NoProject(onCreate: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Logo(88)
        Spacer(Modifier.height(16.dp))
        Text("Pehla project banao", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = TC.Navy)
        Spacer(Modifier.height(6.dp))
        Text(
            "Apne phone ka ek folder chuno. AI usi folder ke andar files padhega aur badlega.",
            fontSize = 14.sp, color = TC.Muted, lineHeight = 20.sp
        )
        Spacer(Modifier.height(20.dp))
        androidx.compose.material3.Button(
            onClick = onCreate,
            colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = TC.Blue)
        ) {
            Icon(Icons.Default.Add, null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text("New project")
        }
    }
}

@Composable
private fun InputArea(vm: AppViewModel, onModel: () -> Unit, onKeys: () -> Unit) {
    var text by remember { mutableStateOf("") }
    val s = vm.settings
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp)
            .padding(top = 4.dp, bottom = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(TC.Soft)
                    .clickable(onClick = onModel)
                    .padding(start = 12.dp, end = 6.dp, top = 7.dp, bottom = 7.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    if (s.mode == Mode.TEAM) "Team · 4 models" else "Single · ${s.singleModel}",
                    fontSize = 12.sp, color = TC.Navy, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Icon(Icons.Default.KeyboardArrowDown, null, tint = TC.Navy, modifier = Modifier.size(18.dp))
            }
            if (!s.hasAnyKey()) {
                Row(
                    Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(TC.RedSoft)
                        .clickable(onClick = onKeys)
                        .padding(horizontal = 10.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(Icons.Default.Warning, null, tint = TC.Red, modifier = Modifier.size(14.dp))
                    Text("API key daalo", fontSize = 12.sp, color = TC.Red, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(28.dp))
                .background(TC.Card)
                .border(1.5.dp, TC.BorderStrong, RoundedCornerShape(28.dp))
                .padding(start = 16.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .weight(1f)
                    .padding(vertical = 10.dp)
            ) {
                BasicTextField(
                    value = text,
                    onValueChange = { text = it },
                    textStyle = TextStyle(fontSize = 15.sp, color = TC.Text),
                    maxLines = 5,
                    cursorBrush = SolidColor(TC.Blue),
                    modifier = Modifier.fillMaxWidth()
                )
                if (text.isEmpty()) {
                    Text("Agent ko kaam batao...", color = TC.Muted, fontSize = 15.sp)
                }
            }
            if (vm.running) {
                IconButton(
                    onClick = { vm.stop() },
                    modifier = Modifier.size(44.dp),
                    colors = IconButtonDefaults.iconButtonColors(containerColor = TC.Navy, contentColor = Color.White)
                ) { Icon(Icons.Default.Stop, contentDescription = "Roko") }
            } else {
                IconButton(
                    onClick = {
                        vm.send(text)
                        text = ""
                    },
                    enabled = text.isNotBlank(),
                    modifier = Modifier.size(44.dp),
                    colors = IconButtonDefaults.iconButtonColors(
                        containerColor = TC.Blue,
                        contentColor = Color.White,
                        disabledContainerColor = TC.BorderStrong,
                        disabledContentColor = Color.White
                    )
                ) { Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Bhejo") }
            }
        }
    }
}

// ------------------------------------------------------------------ drawer

@Composable
private fun DrawerContent(vm: AppViewModel, onClose: () -> Unit, onNewProject: () -> Unit) {
    var pendingDelete by remember { mutableStateOf<Pair<String, () -> Unit>?>(null) }

    ModalDrawerSheet(drawerContainerColor = Color.White, modifier = Modifier.width(310.dp)) {
        Column(Modifier.fillMaxHeight()) {
            Row(
                Modifier.padding(horizontal = 20.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Logo(36)
                Text("TechCode", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = TC.Navy)
            }
            HorizontalDivider(color = TC.Border)

            LazyColumn(
                Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
            ) {
                item { SectionLabel("PROJECTS") }
                items(vm.projects, key = { "p" + it.id }) { p ->
                    DrawerRow(
                        icon = Icons.Default.Folder,
                        text = p.name,
                        selected = p.id == vm.currentProjectId,
                        onClick = {
                            vm.selectProject(p.id)
                            onClose()
                        },
                        onDelete = { pendingDelete = "\"${p.name}\" project hatana hai? Folder ki files safe rahengi." to { vm.deleteProject(p.id) } }
                    )
                }
                item {
                    DrawerRow(icon = Icons.Default.Add, text = "New project", accent = true, onClick = onNewProject)
                }
                if (vm.currentProject != null) {
                    item { Spacer(Modifier.height(8.dp)); SectionLabel("CHATS") }
                    items(vm.projectChats, key = { "c" + it.id }) { c ->
                        DrawerRow(
                            icon = null,
                            text = c.title,
                            selected = c.id == vm.currentChatId,
                            onClick = {
                                vm.openChat(c.id)
                                onClose()
                            },
                            onDelete = { pendingDelete = "Ye chat hatani hai?" to { vm.deleteChat(c.id) } }
                        )
                    }
                    item {
                        DrawerRow(
                            icon = Icons.Default.Add,
                            text = "New chat",
                            accent = true,
                            onClick = {
                                vm.newChat()
                                onClose()
                            }
                        )
                    }
                }
            }
            HorizontalDivider(color = TC.Border)
            Box(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                DrawerRow(
                    icon = Icons.Default.Settings,
                    text = "Settings",
                    onClick = {
                        vm.screen = Screen.Settings
                        onClose()
                    }
                )
            }
        }
    }

    pendingDelete?.let { (msg, action) ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            text = { Text(msg) },
            confirmButton = {
                TextButton(onClick = {
                    action()
                    pendingDelete = null
                }) { Text("Haan, hatao", color = TC.Red) }
            },
            dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("Nahi") } }
        )
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        color = TC.Muted,
        letterSpacing = 1.sp,
        modifier = Modifier.padding(start = 12.dp, top = 10.dp, bottom = 6.dp)
    )
}

@Composable
private fun DrawerRow(
    icon: ImageVector?,
    text: String,
    selected: Boolean = false,
    accent: Boolean = false,
    onClick: () -> Unit,
    onDelete: (() -> Unit)? = null
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) TC.Soft else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(start = 12.dp, top = 2.dp, bottom = 2.dp, end = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            Icon(icon, null, tint = if (accent || selected) TC.Blue else TC.Muted, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(12.dp))
        }
        Text(
            text,
            modifier = Modifier
                .weight(1f)
                .padding(vertical = 12.dp),
            fontSize = 15.sp,
            fontWeight = if (selected || accent) FontWeight.SemiBold else FontWeight.Normal,
            color = if (accent) TC.Blue else if (selected) TC.Navy else TC.Text,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        if (onDelete != null) {
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Hatao", tint = TC.Muted, modifier = Modifier.size(18.dp))
            }
        }
    }
}
