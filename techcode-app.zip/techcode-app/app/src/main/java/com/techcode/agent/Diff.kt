package com.techcode.agent

enum class DType { SAME, ADD, DEL }

data class DLine(val type: DType, val text: String, val oldNo: Int, val newNo: Int)

private fun splitLines(s: String): List<String> {
    if (s.isEmpty()) return emptyList()
    val t = if (s.endsWith("\n")) s.dropLast(1) else s
    return t.split("\n")
}

fun diffLines(oldText: String?, newText: String): List<DLine> {
    val a = splitLines(oldText ?: "")
    val b = splitLines(newText)

    var start = 0
    while (start < a.size && start < b.size && a[start] == b[start]) start++
    var endA = a.size
    var endB = b.size
    while (endA > start && endB > start && a[endA - 1] == b[endB - 1]) {
        endA--
        endB--
    }
    val midA = a.subList(start, endA)
    val midB = b.subList(start, endB)
    val out = ArrayList<DLine>()

    for (i in 0 until start) out.add(DLine(DType.SAME, a[i], i + 1, i + 1))

    val n = midA.size
    val m = midB.size
    if (n.toLong() * m.toLong() > 4_000_000L) {
        for (i in 0 until n) out.add(DLine(DType.DEL, midA[i], start + i + 1, 0))
        for (j in 0 until m) out.add(DLine(DType.ADD, midB[j], 0, start + j + 1))
    } else {
        val dp = Array(n + 1) { IntArray(m + 1) }
        for (i in n - 1 downTo 0) {
            for (j in m - 1 downTo 0) {
                dp[i][j] = if (midA[i] == midB[j]) dp[i + 1][j + 1] + 1 else maxOf(dp[i + 1][j], dp[i][j + 1])
            }
        }
        var i = 0
        var j = 0
        while (i < n && j < m) {
            if (midA[i] == midB[j]) {
                out.add(DLine(DType.SAME, midA[i], start + i + 1, start + j + 1))
                i++
                j++
            } else if (dp[i + 1][j] >= dp[i][j + 1]) {
                out.add(DLine(DType.DEL, midA[i], start + i + 1, 0))
                i++
            } else {
                out.add(DLine(DType.ADD, midB[j], 0, start + j + 1))
                j++
            }
        }
        while (i < n) {
            out.add(DLine(DType.DEL, midA[i], start + i + 1, 0))
            i++
        }
        while (j < m) {
            out.add(DLine(DType.ADD, midB[j], 0, start + j + 1))
            j++
        }
    }

    for (k in endA until a.size) {
        out.add(DLine(DType.SAME, a[k], k + 1, endB + (k - endA) + 1))
    }
    return out
}

fun diffStat(oldText: String?, newText: String): Pair<Int, Int> {
    val d = diffLines(oldText, newText)
    return d.count { it.type == DType.ADD } to d.count { it.type == DType.DEL }
}

/** Keeps [ctx] unchanged lines around each change; a null entry marks a skipped stretch. */
fun collapseContext(lines: List<DLine>, ctx: Int = 3): List<DLine?> {
    val keep = BooleanArray(lines.size)
    for ((i, l) in lines.withIndex()) {
        if (l.type != DType.SAME) {
            for (k in maxOf(0, i - ctx)..minOf(lines.size - 1, i + ctx)) keep[k] = true
        }
    }
    val out = ArrayList<DLine?>()
    var skipped = false
    for ((i, l) in lines.withIndex()) {
        if (keep[i]) {
            out.add(l)
            skipped = false
        } else if (!skipped) {
            out.add(null)
            skipped = true
        }
    }
    return out
}
