package com.techcode.agent

import android.graphics.Color as AndroidColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(AndroidColor.TRANSPARENT, AndroidColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.light(AndroidColor.TRANSPARENT, AndroidColor.TRANSPARENT)
        )
        setContent {
            TechCodeTheme {
                AppRoot()
            }
        }
    }
}

@Composable
fun AppRoot() {
    val vm: AppViewModel = viewModel()
    BackHandler(enabled = vm.screen != Screen.Chat) { vm.screen = Screen.Chat }
    when (val s = vm.screen) {
        Screen.Chat -> ChatScreen(vm)
        Screen.Settings -> SettingsScreen(vm)
        is Screen.Diff -> DiffScreen(vm, s.csId)
    }
}
